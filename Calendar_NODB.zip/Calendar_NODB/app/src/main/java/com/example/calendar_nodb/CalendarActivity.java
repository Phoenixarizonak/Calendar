package com.example.calendar_nodb;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.CalendarView;
import android.widget.TextView;
import android.view.View;

import java.time.Month;

public class CalendarActivity extends AppCompatActivity {


    private  static final String TAG = "CalendarActivity";
    private CalendarView mCalendarView;
    private TextView DateEvents;
    private static Month JANUARY;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.calendar_layout);
        mCalendarView = (CalendarView) findViewById(R.id.calendarView);
        mCalendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {

            @Override
            public void onSelectedDayChange(CalendarView CalendarView, int year, int month, int dayOfMonth) {
                String date = year + "/" + month + "/"+ dayOfMonth ;

                Log.d(TAG, "onSelectedDayChange: yyyy/mm/dmm/dd:" + date);
                String text   = getString(R.string.February_9_2021) ;
                Log.d(TAG, "onSelectedDayChange: " + text );

                Intent intent = new Intent(CalendarActivity.this,MainActivity.class);
               intent.putExtra("text",text);
                intent.putExtra("date",date);
                startActivity(intent);


            }
        });
    };}